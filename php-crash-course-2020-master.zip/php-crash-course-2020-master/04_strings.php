<?php

// Create simple string

// String concatenation

// String functions

// Multiline text and line breaks

// Multiline text and reserve html tags

// https://www.php.net/manual/en/ref.strings.php