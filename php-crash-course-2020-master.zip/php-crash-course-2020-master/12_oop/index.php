<?php

// What is class and instance

// Create Person class in Person.php

// Create instance of Person

// Using setter and getter