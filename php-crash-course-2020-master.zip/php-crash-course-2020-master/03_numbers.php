<?php

// Declaring numbers

// Arithmetic operations

// Assignment with math operators

// Increment operator

// Decrement operator

// Number checking functions

// Conversion

// Number functions

// Formatting numbers

// https://www.php.net/manual/en/ref.math.php
