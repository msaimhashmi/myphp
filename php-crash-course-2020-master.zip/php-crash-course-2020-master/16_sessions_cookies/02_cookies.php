<?php

// How to set cookies

// How to update cookie

// How to delete cookie

