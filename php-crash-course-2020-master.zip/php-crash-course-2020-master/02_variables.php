<?php

// What is a variable

// Variable types

// Declare variables

// Print the variables. Explain what is concatenation

// Print types of the variables

// Print the whole variable

// Change the value of the variable

// Print type of the variable

// Variable checking functions

// Check if variable is defined

// Constants

// Using PHP built-in constants
